import {createApp} from 'vue';

import Layout from './views/layout.vue';

const App = createApp(Layout);

App.mount('#app');