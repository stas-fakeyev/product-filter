<template>
	<div class="attributes" v-if="attributes">
	<h2>Атрибуты</h2>
	<div class="attribute" v-for="attribute in attributes">
	<h3>{{ attribute.name }}</h3>
	<div class="attribute-value" v-if="attribute.attribute_values">
	<div class="value" v-for="value in attribute.attribute_values">
	<input type="checkbox" name="attributes[]" value="{{ value.id }}" />
	<span>{{ value.name }}</span>
	</div>
	</div>
	</div>
	</div>
</template>

<script>
import axios from 'axios';

export default {
data() {
return {
attributes: '',
};
}, /*enddata*/
created() {
axios.get('/api/attributes')
.then(({data}) => {
this.attributes = data.data;
}) /*endthen*/
.catch(({response}) => {
alert('some error');
});
} /*endhook*/
}
</script>