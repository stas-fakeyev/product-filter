<template>
	<div class="categories" v-if="categories">
	<h2>Категории</h2>
		<div class="category" v-for="category in categories" :key="category.id">
	<input type="checkbox" :value="category.id" v-model="selectedCategories" /><span>{{ category.name }}</span>
	</div>
	</div>
</template>

<script>
import axios from 'axios';

export default {
props: {
value: Array,
},
data() {
return {
categories: '',
selectedCategories: this.value,
};
}, /*enddata*/
watch: {
selectedCategories(newValue) {
this.$emit('input', newValue); /* Отправляем изменения в родительский компонент */
}
},
created() {
this.fetchCategories();
}, /*endhook*/
methods: {
fetchCategories() {
axios.get('/api/categories')
.then(({data}) => {
this.categories = data.data;
}) /*endthen*/
.catch(({response}) => {
alert('some error');
});
}
} /*endmethods*/
}
</script>