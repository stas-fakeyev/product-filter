<template>
<div class="root">
<h2>Фильтр товаров</h2>
</div>
<categories v-model="selectedCategories" />
<attributes></attributes>
<products :selectedCategories="selectedCategories" />
</template>

<script>
import Categories from './categories.vue';
import Attributes from './attributes.vue';
import Products from './products.vue';

export default {
components: {
Categories,
Attributes,
Products,
},
data() {
return {
selectedCategories: [],
};
}
}
</script>