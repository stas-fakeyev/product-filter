<template>
<div class="products" v-if="products">
<h2>Товары</h2>
<div class="product" v-for="product in products">
<p>{{ product.name }}</p>
</div>
<div class="pagination">
<ul class="page-numbers">
       <li v-for="page in pages" :key="page" @click="paginatorProducts(page)" :class="{ active: page === currentPage }" >
          <button>{{ page }}</button>
        </li>
</ul>
</div>
</div>
</template>

<script>
import axios from 'axios';
export default {
props: {
selectedCategories: Array,
},
data() {
return {
products: '',
currentPage: 1,
lastPage: 1,
};
}, /*enddata*/
watch: {
selectedCategories() {
this.productsByCategory();
}
},
computed: {
pages() {
const pages = [];
     for (let i = 1; i <= this.lastPage; i++) {
	 pages.push(i);
	 } /*endfor*/
	 return pages;
},
}, /*endcomputed*/
created() {
this.fetchProducts();
}, /*endhook*/
methods: {
paginatorProducts(page = 1) {
return page;
},
fetchProducts() {
const page = this.paginatorProducts();

axios.get(`/api/products?page=${page}`)
.then(({data}) => {
this.products = data.data;

        this.currentPage = data.meta.pagination.current_page;
        this.lastPage = data.meta.pagination.total_pages;
}) /*endthen*/
.catch(({response}) => {
alert(response.data.message);
});
},
productsByCategory() {
const page = this.paginatorProducts();

axios.post('/api/products-bycategories', { categories: this.selectedCategories, page: page})
.then(({data}) => {
this.products = data.data;

        this.currentPage = data.meta.pagination.current_page;
        this.lastPage = data.meta.pagination.total_pages;
}) /*endthen*/
.catch(({response}) => {
alert(response.data.message);
});
}
} /*endmethods*/
}
</script>